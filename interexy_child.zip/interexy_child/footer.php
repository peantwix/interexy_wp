<footer>
    <!-- тут наш футер -->
  </footer>
  <?php wp_footer(); ?>
</body>
</html>
