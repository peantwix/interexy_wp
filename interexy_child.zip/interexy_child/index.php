<?php get_header(); ?>

<section class="main-cta">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <div class="main-cta-content">
        <h1 class="main-cta-content-name"><?php the_title(); ?></h1>
        <div class="main-cta-content-text">
        <?php the_content(); ?>
        </div>
        <button type="button" class="main-cta-content-btn">
          Hire Developers
        </button>
      </div>
  <?php endwhile; endif; ?>
  </section>

<?php get_footer(); ?>

      
