<?php
function my_custom_theme_enqueue_scripts() {
  wp_enqueue_style('main-css', get_template_directory_uri() . '/css/main.css');
}
add_action('wp_enqueue_scripts', 'my_custom_theme_enqueue_scripts');
